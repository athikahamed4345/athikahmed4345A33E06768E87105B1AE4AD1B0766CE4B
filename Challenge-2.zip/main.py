year=int(input())
if(year%4==0):
  print("leap year")
else:
  print("not leap year") 
